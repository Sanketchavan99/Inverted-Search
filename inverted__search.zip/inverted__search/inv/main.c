/*
 *Name	    :Sanket
 *Date		:28/Feb/2024
 *File		:main.c
 *Title		:Main function
 *Description	: main function for the project inverted search
 */
#include "inverted_search.h"
mainnode *hash[27] = {NULL};
int main(int argc, char *argv[])
{
    /* Define the main function here */
    if(argc > 1)
    {
	filenode *filehead = NULL;
	if((read_and_validate(argc,argv,&filehead) == SUCCESS))
	{
	    printf("VALIDATION SUCCESSFULL\n");
		int flag = 0;
	    while(1)
	    {
		menu();
		int choice;
		printf("Enter Choice : ");
		scanf("%d",&choice);
		getchar();
		
		switch(choice)
		{
		    case 1: printf("Database is created for ");
					for(int i=1;i<argc;i++)
					{
						printf("%s ",argv[i]);
					}
					printf("\n");
			    create_database(filehead);
			    flag =1;

			    break;
		    case 2: 
			    Display_database();
			    break;
		    case 3:
			    printf("Enter the word to be Searched : ");
			    char word[30];
			    scanf("%s",word);
			    getchar();
			    search(word);
			    break;
		    case 4:printf("Enter the filename: ");
			   char fname[30];
			   scanf("%s",fname);
			   getchar();
			   save(fname);
			   printf("Database is stored in %s\n",fname);
			   break;
		    case 5:if(flag == 0)
			   {
			       
			       printf("Enter the file name from where to Update :");
			       char str[30];
			       scanf("%s",str);
			       getchar();
			       if(validate_backupfile(str) == SUCCESS)
			       {
				   printf("Validation of backup file successfull\n");
				   update_database(str);
				   printf("Database is updated (");
				   
					for(int i=1;i<argc;i++)
					{
						printf("%s ",argv[i]);
					}
					printf(")\n");
				   flag=1;
			       }
			       else printf("validation unsuccessfull\n");
			   }
			   else
			   {
			       printf("Error : Database is already Created\n");
			   } 
			   break;



		    case 6: return 0;

		}

	    }




	}
	else 
	    printf("ERROR passing Arguments\nUsage: ./a.out <file1.txt> <file2.txt> ... <filen.txt>\n");

    }
    else
    {
	printf("ERROR passing Arguments\nUsage: ./a.out <file1.txt> <file2.txt> ... <filen.txt>\n");
    }
    return 0;

}

int read_and_validate(int argc,char *argv[], filenode **head)
{
	FILE *fptr;
	for(int i=1;i<argc;i++)
	{
		if((strstr(argv[i],".txt") != NULL))
		{
			if(( fptr = fopen(argv[i],"r")) != NULL)
			{
				fseek(fptr,0,SEEK_END);
				if(ftell(fptr) != 0)
				{
					if(*head == NULL)
					{
						filenode *new = malloc(sizeof(filenode));
						strcpy(new->filename,argv[i]);
						new->flink = NULL;
						*head = new;
					}
					else
					{
						filenode *temp = *head;
						while(temp->flink != NULL)
						{
							if(strcmp(temp->filename,argv[i])==0)
							{
								printf("%s is Duplicate\n",argv[i]);
								fclose(fptr);
								continue;
							}
							temp = temp->flink;
						}
						if(strcmp(temp->filename,argv[i])==0)
						{
							printf("%s is Duplicate\n",argv[i]);
							fclose(fptr);
							continue;
						}
						filenode *new = malloc(sizeof(filenode));
						strcpy(new->filename,argv[i]);
						new->flink = NULL;
						temp->flink = new;
					}
				}
				else 
				{
					printf("No content in %s\n",argv[i]);
				}
				fclose(fptr);

			}
			else 
			{
				printf("%s does not exist\n",argv[i]);
			}

		}
		else
		{
			printf("%s is not a .txt file\n",argv[i]);
		}
	}
	if(*head == NULL)
		return FAILURE;
	else return SUCCESS;
}


void menu(void)
{
	printf("1.Create database\n2.Display database\n3.Search database\n4.Save database\n5.Update database\n6.Exit\n");
};

int validate_backupfile(char *str)
{

	FILE *fptr;
	if(strstr(str,".txt") != NULL)
	{
		if((fptr = fopen(str,"r")) != NULL)
		{
			char ch1,ch2;
			ch1 = fgetc(fptr);
			fseek(fptr,-2,SEEK_END);
			ch2 = fgetc(fptr);
			//printf("%c %c \n",ch1,ch2);
			if(ch1 == '#' && ch2 == '#')
				return SUCCESS;
			else 
			{
				printf("File is not in Correct format\n");
				return FAILURE;
			}
			fclose(fptr);


		}
		else 
		{
			printf("%s Does not exist\n",str);
			return FAILURE;
		}
	}
	else 
	{
		printf("%s is not a .txt file\n",str);
		return FAILURE;
	}



}
