/*
*Name           :Sanket
*Date           :04/Feb/2024
*File           :search.c
*Title          :To search the words.
*Description    :Each word is now used to search in the linkedlist. The word has to be compared with
		:each word in the linked list. When found, the file details can be retrieved. Since the
		:linkedlist is in sorted order, the complexity of searching the word in the complete list
		:can be avoided. While string comparison, if the word in linkedlist is greater than the
		:word to be search, it shows the word doesnt exists in the list,
*/
#include "inverted_search.h"

int search (char *word)
{
	/* Definition here */
    int index;
    if((isalpha(word[0]) == 0))
	index = 26;
    else index = toupper(word[0])%65;

    mainnode *temp = hash[index];
    while(temp != NULL)
    {
	if(strcmp(temp->word,word)==0)
	{
	    printf("\nword \"%s\" is present in %d file/s\n",word,temp->filecount);
	    subnode *sub_temp = temp->slink;
	    while(sub_temp != NULL)
	    {
		printf("In file: %-10s%-2d time/s\n",sub_temp->filename,sub_temp->word_count);
		sub_temp = sub_temp->slink;

	    }
	    printf("\n");
	    return SUCCESS;

	}
	temp = temp->mlink;

    }
    printf("NO Such Word Present\n");
    return SUCCESS;

}

