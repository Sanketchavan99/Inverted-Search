/*
*Name           :Sanket
*Date           :28/Feb/2024
*File           :display_output.c
*Title          :To display results.
*Description    :When all the words are searched the ouput list is formed. In this the file with max count
		:(representing maximum word match ) can be selected and displayed. For advanced searched,
		:(weightage of words stored in database linkedlist) can also be used. So the results will be more
		:accurate.
*/
#include "inverted_search.h"

void Display_database(void)
{
	/* Definition here */
    printf("%-10s%-20s%-15s%-15s%-15s\n","[index]","word","filecount","filename","wordcount");
    for(int i=0;i<27;i++)
    {
	if(hash[i] != NULL)
	{
	    int index = i;
	    mainnode *temp = hash[i];
	    while(temp != NULL)
	    {
		printf("%-10d%-20s%-15d",index,temp->word,temp->filecount);
		subnode *sub_temp = temp->slink;
		while(sub_temp != NULL)
		{
		    printf("%-15s%-15d",sub_temp->filename,sub_temp->word_count);
		    sub_temp = sub_temp->slink;
		}
		temp = temp->mlink;
		printf("\n");
	    }
	}

    }
    printf("\n");
}

