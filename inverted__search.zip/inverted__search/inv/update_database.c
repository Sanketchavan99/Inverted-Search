/*
   *Name           :Sanket
   *Date           :04/Feb/2024
   *File           :search.c
   *Title          :T0 update the database
   *Description    :for updating the database 
																   */

#include "inverted_search.h"

int update_database(char *str)
{
    FILE *fptr = fopen(str,"r");
    char arr[300];
    char *token;
    while((fscanf(fptr,"%s",arr)) != EOF)
    {
	token = strtok(arr,"#;");
	int index = atoi(token);
	mainnode *main = malloc(sizeof(mainnode));
	main->mlink = NULL;
	token = strtok(NULL,"#;");
	strcpy(main->word,token);

	token = strtok(NULL,"#;");
	int count = atoi(token);
	main->filecount = count;

 	subnode *sub_temp;
	for(int i=0;i<count;i++)
	{
	    subnode *sub = malloc(sizeof(subnode));
	    token = strtok(NULL,"#;");
	    strcpy(sub->filename,token); 
	    token = strtok(NULL,"#;");
	    int num = atoi(token);
	    sub->word_count = num;

	    if(i==0)
	    {
		main->slink = sub;
		sub_temp = sub;
	    }
	    else
	    {
		sub_temp->slink = sub;
		sub_temp = sub;
	    }

	}

	mainnode *temp = hash[index];
	if(temp == NULL)
	{
	    hash[index] = main;
	}
	else 
	{
	    while(temp->mlink != NULL)
	    {
		temp = temp->mlink;

	    }
	    temp->mlink = main;
	}

    }
    

}
