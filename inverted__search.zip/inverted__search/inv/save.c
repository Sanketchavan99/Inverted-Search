#include "inverted_search.h"

int save(char *fname)
{
    FILE *fptr = fopen(fname,"w");
    if(fptr == NULL)
    {
	printf("Could not open %s\n",fname);
	return FAILURE;
    }
    for(int i=0;i<27;i++)
    {
	if(hash[i] != NULL)
	{
	    
	    mainnode *temp = hash[i];
	    while(temp != NULL)
	    {

	    fprintf(fptr,"#%d;",i);
		subnode *sub_temp = temp->slink;
		fprintf(fptr,"%s;%d;",temp->word,temp->filecount);
		while(sub_temp != NULL)
		{
		    fprintf(fptr,"%s;%d;",sub_temp->filename,sub_temp->word_count);

		    sub_temp = sub_temp->slink;

		}
		fprintf(fptr,"#\n");
		temp = temp->mlink;


	    }

	}
    }
    fclose(fptr);
}



