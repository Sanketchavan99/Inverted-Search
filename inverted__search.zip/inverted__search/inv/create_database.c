/*
 *Name           :Sanket
 *Date           :28/feb/2024
 *File           :create_database.c
 *Title          :To create the database
 *Description    :The list of the files can be provided by storing all the file names in another file, FileList the names of the files which 
 :are to be documented are provided by this file. When a file is added or removed, FileList is changed accordingly.
 :So read the file names and start indexing.
 */
#include "inverted_search.h"
void create_database(filenode *head)
{
    /* Definition here */
    while(head != NULL)
    {
	FILE *fptr = fopen(head->filename,"r");
	if(fptr == NULL)
	{
	    printf("Could Not open %s\n",head->filename);
	}
	char word[30];
	while(fscanf(fptr,"%s",word) != EOF)
	{
	    //printf("%s\n",word);
	    int index;
	    if(isalpha(word[0]) == 0)
		index = 26;
	    else 
		index = toupper(word[0]) % 65;
	    if(hash[index] == NULL)
	    {
		//printf("1\n");
		mainnode *main = malloc(sizeof(mainnode));
		strcpy(main->word,word);
		main->filecount = 1;
		main->mlink = NULL;

		subnode *sub = malloc(sizeof(subnode));
		strcpy(sub->filename,head->filename);
		sub->word_count = 1;
		sub->slink = NULL;

		main->slink = sub;
		hash[index] = main;
	    }
	    else 
	    {

		mainnode *temp = hash[index];
		mainnode *prev = hash[index];
		if(check_word_present(&temp,&prev,word) == SUCCESS)
		{
		    subnode *sub_temp = temp->slink;
		    subnode *sub_prev = temp->slink;
		    if(check_filename_same(&sub_temp,&sub_prev,head->filename) == SUCCESS)
		    {
			//printf("2\n");
			sub_temp->word_count += 1;
		    }
		    else 
		    {
			//printf("3\n");
			subnode *sub = malloc(sizeof(subnode));
			strcpy(sub->filename,head->filename);
			sub->word_count = 1;
			sub->slink = NULL;
			sub_prev->slink = sub;
			temp->filecount += 1;
		    }

		}
		else
		{
		   // printf("4\n");
		    mainnode *main = malloc(sizeof(mainnode));
		    strcpy(main->word,word);
		    main->filecount = 1;
		    main->mlink = NULL;

		    subnode *sub = malloc(sizeof(subnode));
		    strcpy(sub->filename,head->filename);
		    sub->word_count = 1;
		    sub->slink = NULL;

		    main->slink = sub;
		    prev->mlink = main;
		}

	    }
	}
	fclose(fptr);


	head = head->flink;
    }
}

int check_filename_same(subnode **temp,subnode **prev,char *filename)
{
    while( *temp != NULL)
    {
	if(strcmp((*temp)->filename,filename) == 0)
	    return SUCCESS;
	*prev = *temp;
	(*temp) = (*temp)->slink;
    }
    return FAILURE;

}
int check_word_present(mainnode **temp,mainnode **prev, char *word)
{
    while((*temp) != NULL)
    {
	if(strcmp((*temp)->word,word) == 0)
	    return SUCCESS;
	*prev = *temp;
	*temp = (*temp)->mlink;
    }
    return FAILURE;
}



