#ifndef MAIN_H
#define MAIN_H

#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

#define SUCCESS 1
#define FAILURE 0

typedef struct subnode
{
    int word_count;
    char filename[30];
    struct subnode *slink;
}subnode;

typedef struct mainnode
{
    char word[30];
    int filecount;
    struct subnode *slink;
    struct mainnode *mlink;
}mainnode;

typedef struct filenode
{
    char filename[30];
    struct filenode *flink;
}filenode;

extern mainnode *hash[27];

int read_and_validate(int ,char **,filenode **);
void menu(void);
void create_database(filenode *);

int check_filename_same(subnode **,subnode **,char *);
int check_word_present(mainnode **,mainnode **,char*);
void Display_database(void);
int search(char *);
int save(char*);
int validate_backupfile(char *);
int update_database(char *);
#endif
